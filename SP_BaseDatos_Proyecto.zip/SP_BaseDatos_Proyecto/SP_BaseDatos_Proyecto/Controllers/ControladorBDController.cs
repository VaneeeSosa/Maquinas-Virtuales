﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SP_BaseDatos_Proyecto.Models;
using System;
using System.Data;
using System.Data.SqlClient;

namespace SP_BaseDatos_Proyecto.Controllers
{
    public class ControladorBDController : Controller
    {
        private readonly string _connectionString;

        public ControladorBDController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View(new Config());
        }

        [HttpPost]
        public ActionResult Create(Config config)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string spMessage = CreateDatabase(config);

                    if (string.IsNullOrWhiteSpace(spMessage))
                    {
                        spMessage = "Base de datos creada exitosamente.";
                    }
                    ViewBag.Message = spMessage;
                }
                catch (Exception ex)
                {
                    ViewBag.Message = "Error: " + ex.Message;
                }
            }
            return View(config);
        }

        private string CreateDatabase(Config config)
        {
            string infoMessages = string.Empty;

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                // InfoMessage captura los mensajes de PRINT enviados por el SP.
                connection.InfoMessage += (sender, e) =>
                {
                    infoMessages += e.Message + Environment.NewLine;
                };

                connection.Open();
                using (SqlCommand command = new SqlCommand("sp_CrearBaseDatosValidacion", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@NombreDB", config.NombreDB);
                    command.Parameters.AddWithValue("@RutaMDF", config.RutaMDF);
                    command.Parameters.AddWithValue("@TamanoInicialMDF", int.Parse(config.TamanoInicialMDF));
                    command.Parameters.AddWithValue("@CrecimientoMDF", int.Parse(config.CrecimientoMDF));
                    command.Parameters.AddWithValue("@RutaLDF", config.RutaLDF);
                    command.Parameters.AddWithValue("@TamanoInicialLDF", int.Parse(config.TamanoInicialLDF));
                    command.Parameters.AddWithValue("@CrecimientoLDF", int.Parse(config.CrecimientoLDF));

                    // Agregamos un parámetro para capturar el valor de retorno del SP.
                    SqlParameter returnParameter = new SqlParameter();
                    returnParameter.Direction = ParameterDirection.ReturnValue;
                    command.Parameters.Add(returnParameter);

                    command.ExecuteNonQuery();

                    int returnValue = (int)returnParameter.Value;
                  
                }
            }
            return infoMessages;
        }

        [HttpGet]
        public ActionResult List()
        {
            List<string> databases = new List<string>();

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                // Consulta para obtener el nombre de todas las bases de datos
                using (SqlCommand command = new SqlCommand("SELECT name FROM sys.databases ORDER BY name", connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            databases.Add(reader["name"].ToString());
                        }
                    }
                }
            }

            return View(databases);
        }

    }
}
