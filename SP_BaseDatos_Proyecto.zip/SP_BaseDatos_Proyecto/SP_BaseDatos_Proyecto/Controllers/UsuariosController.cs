﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.SqlClient;
using System.Data;

namespace SP_BaseDatos_Proyecto.Controllers
{
    public class UsuariosController : Controller
    {
        private readonly IConfiguration _configuration;

        public UsuariosController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            // Obtener la lista de bases de datos (se omiten las de sistema)
            List<SelectListItem> databases = new List<SelectListItem>();
            string query = "SELECT name FROM sys.databases WHERE database_id > 4"; // Ajusta el filtro según necesites
            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            databases.Add(new SelectListItem
                            {
                                Value = reader["name"].ToString(),
                                Text = reader["name"].ToString()
                            });
                        }
                    }
                }
            }
            ViewBag.Databases = databases;
            return View();
        }

        [HttpPost]
        public IActionResult CreateUser(string loginName, string userName, string password, string databaseName, string permissions, string roles)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("sp_PermisosUsuarios", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@LoginName", loginName);
                        cmd.Parameters.AddWithValue("@UserName", userName);
                        cmd.Parameters.AddWithValue("@Password", password);
                        cmd.Parameters.AddWithValue("@DatabaseName", databaseName);
                        cmd.Parameters.AddWithValue("@Permissions", permissions);
                        cmd.Parameters.AddWithValue("@Roles", roles);

                        cmd.ExecuteNonQuery();
                    }
                }
                ViewBag.Message = "Usuario creado exitosamente.";
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Error: " + ex.Message;
            }

            // Recargar la lista de bases de datos para la vista
            List<SelectListItem> databases = new List<SelectListItem>();
            string query = "SELECT name FROM sys.databases WHERE database_id > 4";
            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            databases.Add(new SelectListItem
                            {
                                Value = reader["name"].ToString(),
                                Text = reader["name"].ToString()
                            });
                        }
                    }
                }
            }
            ViewBag.Databases = databases;

            return View("Index");
        }


        [HttpGet]
        public IActionResult GetUsers()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT name FROM sys.database_principals WHERE type IN ('S', 'U', 'G')", conn))
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    da.Fill(dt);
                }
            }
            return View(dt);
        }

        [HttpGet]
        public IActionResult History(DateTime? fechaInicio, DateTime? fechaFin, string operacion)
        {
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                conn.Open();

                string query = @"
            SELECT Id, Operacion, Usuario, Fecha 
            FROM HistorialOperaciones
            WHERE 
                (@fechaInicio IS NULL OR Fecha >= @fechaInicio)
                AND (@fechaFin IS NULL OR Fecha <= @fechaFin)
                AND (@operacion IS NULL OR Operacion = @operacion)
            ORDER BY Fecha DESC";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@fechaInicio", fechaInicio ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@fechaFin", fechaFin ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@operacion", string.IsNullOrEmpty(operacion) ? (object)DBNull.Value : operacion);

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }

            return View(dt);
        }
    }
}
