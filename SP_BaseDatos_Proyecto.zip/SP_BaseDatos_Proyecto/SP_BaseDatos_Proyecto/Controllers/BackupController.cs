﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SP_BaseDatos_Proyecto.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace SP_BaseDatos_Proyecto.Controllers
{
    public class BackupController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<BackupController> _logger;

        // Ruta base para los backups en Windows
        private readonly string _backupBasePath;

        public BackupController(IConfiguration configuration, ILogger<BackupController> logger)
        {
            _configuration = configuration;
            _logger = logger;

            _backupBasePath = _configuration.GetValue<string>("BackupBasePath") ?? @"C:\BackPrueba\Backups";

        }

        // GET: BackupController
        public ActionResult Index()
        {
            CargarBasesDatos();
            return View();
        }

        // POST: BackupController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(string databaseName, string backupType)
        {
            try
            {
                // Validar parámetros
                if (string.IsNullOrWhiteSpace(databaseName))
                    throw new ArgumentException("Seleccione una base de datos");
                if (string.IsNullOrWhiteSpace(backupType))
                    throw new ArgumentException("Seleccione el tipo de backup");

                using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
                {
                    using (var cmd = new SqlCommand("sp_RespaldarBaseDatos", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NombreBaseDatos", databaseName);
                        cmd.Parameters.AddWithValue("@TipoBackup", backupType);

                        conn.Open();
                        var resultado = cmd.ExecuteScalar().ToString();
                        ViewBag.Message = resultado;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en backup");
                ViewBag.Message = $"Error: {ex.Message}";
            }

            CargarBasesDatos();
            return View("Index");
        }

        private void CargarBasesDatos()
        {
            var databases = new List<dynamic>();
            using (var conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var cmd = new SqlCommand("SELECT name FROM sys.databases WHERE database_id > 4", conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        databases.Add(new
                        {
                            Value = reader["name"].ToString(),
                            Text = reader["name"].ToString()
                        });
                    }
                }
            }
            ViewBag.Databases = databases;
        }


        // Acción para listar los backups
        public IActionResult ListBackups()
        {
            var backups = new List<BackupFileViewModel>();

            try
            {
                if (Directory.Exists(_backupBasePath))
                {
                    // Busca archivos con extensión .bak o .trn en todas las subcarpetas
                    var files = Directory.GetFiles(_backupBasePath, "*.*", SearchOption.AllDirectories)
                                         .Where(f => f.EndsWith(".bak", StringComparison.OrdinalIgnoreCase) ||
                                                     f.EndsWith(".trn", StringComparison.OrdinalIgnoreCase));

                    foreach (var file in files)
                    {
                        FileInfo fi = new FileInfo(file);
                        // Obtiene la ruta relativa (para pasarla como parámetro en el enlace de descarga)
                        string relativePath = file.Substring(_backupBasePath.Length)
                                                  .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);

                        backups.Add(new BackupFileViewModel
                        {
                            FileName = fi.Name,
                            RelativePath = relativePath,
                            LastWriteTime = fi.LastWriteTime
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al listar los backups.");
            }

            return View(backups);
        }

        // Acción para descargar un backup
        public IActionResult Download(string relativePath)
        {
            if (string.IsNullOrEmpty(relativePath))
            {
                return BadRequest();
            }

            // Combina la ruta base con la ruta relativa del archivo
            string filePath = Path.Combine(_backupBasePath, relativePath);

            if (!System.IO.File.Exists(filePath))
            {
                return NotFound();
            }

            var memory = new MemoryStream();
            using (var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                stream.CopyTo(memory);
            }
            memory.Position = 0;
            return File(memory, "application/octet-stream", Path.GetFileName(filePath));
        }
    }
}
