﻿namespace SP_BaseDatos_Proyecto.Models
{
    public class Config
    {
        public string NombreDB { get; set; }
        public string RutaMDF { get; set; }
        public string TamanoInicialMDF { get; set; }
        public string CrecimientoMDF { get; set; }
        public string RutaLDF { get; set; }
        public string TamanoInicialLDF { get; set; }
        public string CrecimientoLDF { get; set; }
    }
}
