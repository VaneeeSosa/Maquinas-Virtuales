﻿namespace SP_BaseDatos_Proyecto.Models
{
    public class BackupFileViewModel
    {
        public string FileName { get; set; }
        public string RelativePath { get; set; } // Ruta relativa a la carpeta base
        public DateTime LastWriteTime { get; set; }
    }
}
