﻿using System.ComponentModel.DataAnnotations;

namespace SP_BaseDatos_Proyecto.Models
{
    public class backupModel
    {
        [Required(ErrorMessage = "El nombre de la base de datos es requerido.")]
        [Display(Name = "Nombre de la Base de Datos")]
        public string DatabaseName { get; set; }

        [Required(ErrorMessage = "El tipo de backup es requerido.")]
        [Display(Name = "Tipo de Backup")]
        public string BackupType { get; set; }

        [Required(ErrorMessage = "La ruta base es requerida.")]
        [Display(Name = "Ruta Base de Almacenamiento")]
        public string BaseFolder { get; set; }

        // Lista de archivos de backup generados
        public IEnumerable<BackupMongo> BackupFiles { get; set; }
    }

    // Modelo para la configuración de rutas de almacenamiento de backups
    public class BackupConfigViewModel
    {
        [Required(ErrorMessage = "La ruta base es requerida.")]
        [Display(Name = "Ruta Base de Almacenamiento")]
        public string BaseBackupPath { get; set; }
    }

    // Modelo que representa un archivo de backup
    public class BackupMongo
    {
        public string FileName { get; set; }
        public DateTime CreatedDate { get; set; }
        public string BackupType { get; set; }
    }
}
